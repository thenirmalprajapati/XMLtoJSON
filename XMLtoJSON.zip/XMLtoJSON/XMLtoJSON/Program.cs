﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Xsl;

namespace XMLtoJSON
{
    class Program
    {
        static void Main(string[] args)
        {
            string baseName = @"C:\Users\Admin\source\repos\XMLtoJSON\XMLtoJSON";
            XslTransform myXslTransfom = new XslTransform();

            myXslTransfom.Load(baseName + "\\Customer.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomer.json");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CustomerNotes.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomerNotes.json");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CustomerReference.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomerReference.json");

            myXslTransfom = new XslTransform();
            myXslTransfom.Load(baseName + "\\CustomerCommunication.xslt");
            myXslTransfom.Transform(baseName + "\\Customer.xml", baseName + "\\OutputCustomerCommunication.json");

        }
    }
}
