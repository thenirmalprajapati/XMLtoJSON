﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace XMLtoJSON
{
    class RequestMaker
    {



        private String GetValueFromXML(String MainXML, String Design, String StartingXMLTag, out Boolean IsValueThere)
        {
            IsValueThere = false;
            String ReturnValue = "";

            try
            {
                String[] myXmlDesign = { };
                if (Design.Contains("{{") || Design.Contains("{SPACE}") || Design.Contains("{NEWLINE}") || Design.Contains("{NULL}"))
                {
                    myXmlDesign = Design.Split('+');
                }
                else
                {
                    myXmlDesign = new string[] { Design };
                }

                foreach (var itemXml in myXmlDesign)
                {

                    if (itemXml.Contains("{{") && itemXml.Contains("}}"))
                    {

                        XDocument xdoc = new XDocument();
                        xdoc = XDocument.Parse(MainXML);

                        String[] DesignArray;

                        if (String.IsNullOrEmpty(StartingXMLTag))
                        {
                            Design = itemXml.Replace("{{", "").Replace("}}", "").Trim();
                            DesignArray = Design.Split('.');
                        }
                        else
                        {
                            Design = StartingXMLTag + "." + itemXml.Replace("{{", "").Replace("}}", "").Trim();
                            DesignArray = Design.Split('.');
                        }

                        #region Fetch From XML using Element method

                        if (DesignArray.Count() == 1)
                        {
                            if (xdoc.Element(DesignArray[0]) != null)
                            {
                                if (!String.IsNullOrEmpty(xdoc.Element(DesignArray[0]).Value))
                                {
                                    IsValueThere = true;
                                    ReturnValue = ReturnValue + xdoc.Element(DesignArray[0]).Value;
                                }
                            }
                        }
                        else if (DesignArray.Count() == 2)
                        {
                            if (xdoc.Element(DesignArray[0]) != null)
                            {
                                if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]) != null)
                                {
                                    if (!String.IsNullOrEmpty(xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Value))
                                    {
                                        IsValueThere = true;
                                        ReturnValue = ReturnValue + xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Value;
                                    }
                                }
                            }
                        }
                        else if (DesignArray.Count() == 3)
                        {
                            if (xdoc.Element(DesignArray[0]) != null)
                            {
                                if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]) != null)
                                {
                                    if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]) != null)
                                    {
                                        if (!String.IsNullOrEmpty(xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Value))
                                        {
                                            IsValueThere = true;
                                            ReturnValue = ReturnValue + xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Value;
                                        }
                                    }
                                }
                            }

                        }
                        else if (DesignArray.Count() == 4)
                        {
                            if (xdoc.Element(DesignArray[0]) != null)
                            {
                                if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]) != null)
                                {
                                    if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]) != null)
                                    {
                                        if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Element(DesignArray[3]) != null)
                                        {
                                            if (!String.IsNullOrEmpty(xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Element(DesignArray[3]).Value))
                                            {
                                                IsValueThere = true;
                                                ReturnValue = ReturnValue + xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Element(DesignArray[3]).Value;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else if (DesignArray.Count() == 5)
                        {
                            if (xdoc.Element(DesignArray[0]) != null)
                            {
                                if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]) != null)
                                {
                                    if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]) != null)
                                    {
                                        if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Element(DesignArray[3]) != null)
                                        {
                                            if (xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Element(DesignArray[3]).Element(DesignArray[4]) != null)
                                            {
                                                if (!String.IsNullOrEmpty(xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Element(DesignArray[3]).Element(DesignArray[4]).Value))
                                                {
                                                    IsValueThere = true;
                                                    ReturnValue = ReturnValue + xdoc.Element(DesignArray[0]).Element(DesignArray[1]).Element(DesignArray[2]).Element(DesignArray[3]).Element(DesignArray[4]).Value;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            IsValueThere = true;
                            // When we passed Default Value in the Class then need to set in
                            ReturnValue = ReturnValue + Design;
                        }
                        #endregion
                    }
                    else if (itemXml == "{SPACE}")
                    {
                        ReturnValue = ReturnValue + " ";
                    }
                    else if (itemXml == "{NEWLINE}")
                    {
                        ReturnValue = ReturnValue + System.Environment.NewLine;
                    }
                    else if (itemXml == "\\n")
                    {
                        ReturnValue = ReturnValue + "\n";
                    }
                    else if (itemXml == "{NULL}")
                    {
                        ReturnValue = ReturnValue + String.Empty;
                    }
                    else
                    {
                        IsValueThere = true;
                        ReturnValue = ReturnValue + itemXml;
                    }
                } // For Each
            }
            catch (Exception ex)
            {
                //TxDownloaderProLogic.SaveError(objUserSession.UserName, " String GetValueFromXML_TRIM()", "RecordID = " + RecordID + " ; DesignItem :" + Design, ex);
            }

            return ReturnValue;
        }

    }
}
